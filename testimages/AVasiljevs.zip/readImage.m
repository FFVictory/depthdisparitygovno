function [ image ] = readImage( path )
%UNTITLED8 Summary of this function goes here
%   Detailed explanation goes here
    image = imread(path);
end

